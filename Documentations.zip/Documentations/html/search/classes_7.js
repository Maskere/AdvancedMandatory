var searchData=
[
  ['mylogger_0',['MyLogger',['../class_mandatory_1_1_my_logger.html',1,'Mandatory']]]
];
