var searchData=
[
  ['loot_0',['Loot',['../class_mandatory_1_1_creature.html#a755f32031db1d759c516e3a528551fca',1,'Mandatory::Creature']]]
];
