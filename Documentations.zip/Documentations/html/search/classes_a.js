var searchData=
[
  ['size_0',['Size',['../struct_mandatory_1_1_size.html',1,'Mandatory']]]
];
