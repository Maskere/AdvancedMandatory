var searchData=
[
  ['wrappeditem_0',['wrappedItem',['../class_mandatory_1_1_defence_item_decorator.html#af43a334caea73e278374c96d4cb82a9a',1,'Mandatory::DefenceItemDecorator']]],
  ['wrappedweapon_1',['wrappedWeapon',['../class_mandatory_1_1_offence_item_decorator.html#a67658ab97c0c95cc076e0c3520a3544e',1,'Mandatory::OffenceItemDecorator']]]
];
