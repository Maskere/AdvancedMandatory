var searchData=
[
  ['x_0',['X',['../struct_mandatory_1_1_position.html#a49a9376a2b83d07be9608e8e4824304c',1,'Mandatory.Position.X'],['../struct_mandatory_1_1_size.html#a42a60a74cc4f82a80cfcffa5f6b93517',1,'Mandatory.Size.X']]]
];
