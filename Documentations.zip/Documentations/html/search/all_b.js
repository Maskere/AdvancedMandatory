var searchData=
[
  ['offence_0',['Offence',['../class_mandatory_1_1_creature.html#ab1316adbb951e1b0ba9aaa18368158c1',1,'Mandatory::Creature']]],
  ['offenceitemdecorator_1',['OffenceItemDecorator',['../class_mandatory_1_1_offence_item_decorator.html',1,'Mandatory.OffenceItemDecorator'],['../class_mandatory_1_1_offence_item_decorator.html#aae7e3ef2c2aaef9d4f9526d98b456eb2',1,'Mandatory.OffenceItemDecorator.OffenceItemDecorator()']]],
  ['operator_2b_2',['operator+',['../struct_mandatory_1_1_position.html#a2eedf347c406bacd67e67f09cd7a956a',1,'Mandatory.Position.operator+()'],['../struct_mandatory_1_1_size.html#a5878f41180d9b2e0489882c1776b080e',1,'Mandatory.Size.operator+()']]],
  ['operator_2d_3',['operator-',['../struct_mandatory_1_1_position.html#ad6da3748bd6239693aa40f3707745bc1',1,'Mandatory.Position.operator-()'],['../struct_mandatory_1_1_size.html#a41615ac6c98e5d6f3a252ed19b55cdac',1,'Mandatory.Size.operator-()']]]
];
