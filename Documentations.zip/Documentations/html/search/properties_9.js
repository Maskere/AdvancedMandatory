var searchData=
[
  ['slot_0',['Slot',['../class_mandatory_1_1_armor.html#ab2a0baaee09eb3bbe6942c84b68fd09b',1,'Mandatory.Armor.Slot'],['../class_mandatory_1_1_weapon.html#ae53f385ef85f1aaff16f7be3c1b6958f',1,'Mandatory.Weapon.Slot']]]
];
