var searchData=
[
  ['offence_0',['Offence',['../class_mandatory_1_1_creature.html#ab1316adbb951e1b0ba9aaa18368158c1',1,'Mandatory::Creature']]]
];
