var searchData=
[
  ['taketurn_0',['TakeTurn',['../class_mandatory_1_1_creature.html#a373f29c8655245f6df5959136c119cb1',1,'Mandatory::Creature']]],
  ['tostring_1',['ToString',['../class_mandatory_1_1_game_object.html#a3da9e4282a807cebe9b3199c3bde0893',1,'Mandatory::GameObject']]]
];
