var searchData=
[
  ['defence_0',['Defence',['../class_mandatory_1_1_creature.html#a7f007ea9f12184fab5d4d1288ed6dfca',1,'Mandatory::Creature']]]
];
