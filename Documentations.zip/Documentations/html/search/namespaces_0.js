var searchData=
[
  ['mandatory_0',['Mandatory',['../namespace_mandatory.html',1,'']]]
];
