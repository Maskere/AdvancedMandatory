var searchData=
[
  ['mandatory_0',['Mandatory',['../namespace_mandatory.html',1,'']]],
  ['move_1',['Move',['../class_mandatory_1_1_creature.html#a89e2c251e50782195c44b9fd157bb93b',1,'Mandatory::Creature']]],
  ['mylogger_2',['MyLogger',['../class_mandatory_1_1_my_logger.html',1,'Mandatory']]]
];
